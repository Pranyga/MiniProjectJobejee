<?php
session_start();

$conn=mysqli_connect("localhost","root","","jobejee");
if(!mysqli_connect_error())
{

                    $designation1=$_POST['designation'];
                    $qualification1=$_POST['qualification'];
                    $company1=$_POST['company'];
                    $experience1=$_POST['experience'];                    
                    $salary1=$_POST['salary'];
                    $skill1=$_POST['skill'];
                    $description1=$_POST['description'];
                    $information1=$_POST['information'];
                    $email1=$_POST['email'];                    
                    $mobile1=$_POST['mobile'];
                    $domain1=$_POST['domain'];
                    $logged1= $_SESSION['logged'];                
                    
$a=mysqli_query($conn,"INSERT INTO jobad(designation,qualification,company,experience,salary,skill,description,information,email,mobile,logged,domain)
	VALUES ('$designation1','$qualification1','$company1','$experience1','$salary1','$skill1','$description1','$information1','$email1','$mobile1','$logged1','$domain1')");
if($a)
{
	header("location:previouspost.php");
     
	
}
else
{
	echo "invalid";
}}
?>