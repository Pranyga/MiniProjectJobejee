<?php

$conn=mysqli_connect("localhost","root","","jobejee");
session_start();
 
$sql="DELETE FROM jobad WHERE sno='$_GET[no]'";
if(mysqli_query($conn,$sql))
	header("refresh:1;url=previouspost.php");

else
	echo "Not Deleted";

?>