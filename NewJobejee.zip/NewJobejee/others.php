<?php
$conn=mysqli_connect("localhost","root","","jobejee");
session_start();
$sql="SELECT * FROM jobad WHERE domain='others'";
$records=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html>
<head>
	 <link rel="stylesheet" href="navstyles.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url(pic5.jpg);
  background-repeat: no-repeat;
  background-position: center;
  background-size: cover;

}

/* Float four columns side by side */
.column {
  float: left;
  width: 33%;
  padding: 25px 25px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 10px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}

	table,td{
				padding: 6px;
				padding-left: 10px;
				text-align:left;
			}
			.dropbtn {
  background-color: black;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;

 

  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 22px 26px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;

}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
</head>	

<body>
	 <div id='cssmenu'>
<ul>
   <li class='active'><a href='jobview.php'>All Ads</a></li>
   </li>
   	<li class='dropdown'><a href='#'>
                  Domain</a>
  <div class="dropdown-content" >
    <a href="software.php">Software</a>
    <a href="electrical.php">Electrical</a>
    <a href="construction.php">Construction</a>
     <a href="medical.php">Medical</a>
      <a href="others.php">Others</a>
  </div>
</li>
 <li><a href='logout.php'>Logout</a></li>
</ul>
</div>
   

  


	<div class="row">
	
<?php
while($jobad=mysqli_fetch_assoc($records)){

       echo "<div class=column>";
    echo "<div class=card>";
            
	
	
	echo "<table>";

	
	echo "<tr><td><b>Designation<b></td><td>:</td><td>".$jobad['designation']."</td></tr>";
	echo "<tr><td><b>Qualification<b></td><td>:</td><td>".$jobad['qualification']."</td></tr>";
	echo "<tr><td><b>Company<b></td><td>:</td><td>".$jobad['company']."</td></tr>";
	echo "<tr><td><b>Experience<b></td><td>:</td><td>".$jobad['experience']."</td></tr>";
	echo "<tr><td><b>Salary<b></td><td>:</td><td>".$jobad['salary']."</td></tr>";
	echo "<tr><td><b>Skills Required<b></td><td>:</td><td>".$jobad['skill']."</td></tr>";
	echo "<tr><td><b>Description<b></td><td>:</td><td>".$jobad['description']."</td></tr>";
	echo "<tr><td><b>Other Informations<b></td><td>:</td><td>".$jobad['information']."</td></tr>";
	echo "<tr><td><b>Email<b></td><td>:</td><td>".$jobad['email']."</td></tr>";
	echo "<tr><td><b>Mobile<b></td><td>:</td><td>".$jobad['mobile']."</td></tr>";
	echo "<tr><td><b>Domain<b></td><td>:</td><td>".$jobad['domain']."</td></tr>";
	
	
	echo "</table>"; 
	echo "<br>";
	
		
	
	
	 echo "</div>";
      echo "</div>";
       
}	
?>
</div>
</body>
</html>