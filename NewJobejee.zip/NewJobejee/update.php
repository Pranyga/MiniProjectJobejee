<?php

$conn=mysqli_connect("localhost","root","","jobejee");
session_start();
$no1=$_GET['no'];
$sql="DELETE FROM jobad WHERE sno='$no1'";
if(mysqli_query($conn,$sql))
	echo " ";

else
	echo " ";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Job Advertisement</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="adcss/style.css">
    <link rel="stylesheet" href="navstyles.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
    <script type="text/javascript">
        function validate() {
             no=document.jobad.mobile.value;
            if((no<6000000000)||(no>9999999999)){
                alert("Enter valid Mobile Number");
                return false;
            }
        }
        </script>
</head>
<body>
    
    

    <div class="main">

        <div class="container">
            <form method="POST" name="jobad" action="jobad.php" class="appointment-form" id="jobad" onsubmit="return validate()">
                <h2>ad posting form</h2>
                <div class="form-group-1">
                   
                    <input type="text" name="designation" id="Designation" placeholder="Designation" value="<?php echo $_GET['des'] ;?>" required />
 <input type="text" name="qualification" id="Qualification" placeholder="Qualification" value="<?php echo $_GET['qua'] ;?>" required />
                     <input type="text" name="company" id="Company" placeholder="Company" value="<?php echo $_GET['com'];?>" required />
<input type="text" name="experience" id="Experience in years" value="<?php echo $_GET['exp'];?>" placeholder="Experience in years" />

 <input type="text" name="salary" id="Salary" placeholder="Salary" value="<?php echo $_GET['sal'];?>" />

                    <input type="email" name="email" id="email" placeholder="Email" value="<?php echo $_GET['mail'];?>"  required />
                    <input type="number" name="mobile" id="mobile" placeholder="Mobile number" value="<?php echo $_GET['mob'];?>" required />
                  
                </div>
                <div class="form-group-2">
                    <h3>How would you like to differentiate skill set?</h3>
<input type="text" name="skill" id="Skills required" placeholder="Skills required" value="<?php echo $_GET['ski'];?>" />
<input type="text" name="description" id="Job description" placeholder="Job description" value="<?php echo $_GET['desc'];?>"/>

<input type="text" name="information" id="Other information" placeholder="Other information" value="<?php echo $_GET['info'];?>"/>
                    <div class="select-list">
                        <select name="domain" id="domain" required>
                            <option seleected value="">choose domain</option>
                            <option value="software">Software</option>
 <option value="electrical">Electrical</option>
 <option value="construction">Construction</option>
 <option value="medical">Medical</option>
 <option value="others">Others</option>
                        </select>
                    </div>
                    
                </div>
                <div class="form-submit">
                    <input type="submit" name="submit" id="submit" class="submit" value="Post" />
                </div>
            </form>
        </div>

    </div>

    <!-- JS -->
    <script src="advendor/jquery/jquery.min.js"></script>
    <script src="adjs/main.js"></script>
</body>
</html>                   






