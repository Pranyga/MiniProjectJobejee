<?php

$conn=mysqli_connect("localhost","root","","jobejee");
if(!mysqli_connect_error())
{

                    $first_name1=$_POST['first_name'];
                    $last_name1=$_POST['last_name'];
                    $company1=$_POST['company'];
                    $email1=$_POST['email'];
                    $mobile1=$_POST['mobile'];                 
                    $password1=$_POST['password'];
                    $confirm1=$_POST['confirm'];

$a=mysqli_query($conn,"INSERT INTO regprovider(first_name,last_name,company,email,mobile,password,confirm)
    VALUES ('$first_name1','$last_name1','$company1','$email1','$mobile1','$password1','$confirm1')");
if($a)
{
    header("location:loginprovider.html");
}
else
{
    echo "Invalid Email";
}


} 

?>