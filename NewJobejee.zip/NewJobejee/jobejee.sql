-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2019 at 06:36 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobejee`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobad`
--

CREATE TABLE `jobad` (
  `sno` int(11) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `company` varchar(100) NOT NULL,
  `experience` varchar(50) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `information` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `logged` varchar(50) NOT NULL,
  `domain` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobad`
--

INSERT INTO `jobad` (`sno`, `designation`, `qualification`, `company`, `experience`, `salary`, `skill`, `description`, `information`, `email`, `mobile`, `logged`, `domain`) VALUES
(7, 'Electrical Technician', 'B.E ', 'XYZ technologies', '4', '35,000', '', '', '', 'pranyga1999@gmail.com', 9952607677, 'pranyga1999@gmail.com', 'Electrical'),
(8, 'Receptionist', '12th pass', 'XYZ technologies', '1', '20,000', '', '', '', 'pranyga1999@gmail.com', 9952607677, 'pranyga1999@gmail.com', 'Others'),
(21, 'Programmer', 'B.Tech', 'ABC technologies', '3', '', '', '', 'Skills in programming languages,web design,cloud computing,data mining and few latest technologies ', 'princyravindran@gmail.com', 7502456971, 'princyravindran@gmail.com', 'construction');

-- --------------------------------------------------------

--
-- Table structure for table `regexpector`
--

CREATE TABLE `regexpector` (
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `qualification` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `confirm` varchar(20) NOT NULL,
  `domain` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regexpector`
--

INSERT INTO `regexpector` (`first_name`, `last_name`, `qualification`, `email`, `mobile`, `password`, `confirm`, `domain`) VALUES
('Preethi', 'V', 'B.Tech', 'preethi061999@gmail.com', 9952607677, '1234567890', '1234567890', 'Software'),
('Princy', 'R', 'B.Tech', 'princyravindran@gmail.com', 7502456971, '1234567890', '1234567890', 'Electrical');

-- --------------------------------------------------------

--
-- Table structure for table `regprovider`
--

CREATE TABLE `regprovider` (
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `company` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `confirm` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regprovider`
--

INSERT INTO `regprovider` (`first_name`, `last_name`, `company`, `email`, `mobile`, `password`, `confirm`) VALUES
('Pranyga', 'K', 'XYZ technologies', 'pranyga1999@gmail.com', 9952607677, 'qwerty', 'qwerty'),
('Princy', 'R', 'MCET', 'princyravin@gmail.com', 7502456971, '123', '123'),
('Princy', 'R', 'ABC technologies', 'princyravindran@gmail.com', 7502456971, '1234567890', '1234567890');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jobad`
--
ALTER TABLE `jobad`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `regexpector`
--
ALTER TABLE `regexpector`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `regprovider`
--
ALTER TABLE `regprovider`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobad`
--
ALTER TABLE `jobad`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
