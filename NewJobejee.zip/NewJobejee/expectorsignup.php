<?php

$conn=mysqli_connect("localhost","root","","jobejee");
if(!mysqli_connect_error())
{

                    $first_name1=$_POST['first_name'];
                    $last_name1=$_POST['last_name'];
                    $qualification1=$_POST['qualification'];
                    $email1=$_POST['email'];
                    $mobile1=$_POST['mobile'];                 
                    $password1=$_POST['password'];
                    $confirm1=$_POST['confirm'];
                    $domain1=$_POST['domain'];

$a=mysqli_query($conn,"INSERT INTO regexpector(first_name,last_name,qualification,email,mobile,password,confirm,domain)
	VALUES ('$first_name1','$last_name1','$qualification1','$email1','$mobile1','$password1','$confirm1','$domain1')");
if($a)
{
	header("location:loginexpector.html");
}
else
{
	echo "Invalid Email!";
}


}
  

?>