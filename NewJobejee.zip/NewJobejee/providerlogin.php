<?php
$conn=mysqli_connect("localhost","root","","jobejee");
session_start(); 

$email1=($_POST['email']);
$password1=($_POST['password']);
$_SESSION['logged']=($_POST['email']);


$result=mysqli_query($conn,"SELECT * FROM regprovider WHERE email='$email1' and password='$password1'");

while(mysqli_fetch_array($result,MYSQLI_ASSOC)){
	
  if(isset($_SESSION['logged'])){


  header("location:jobad.html");
}}

if(!mysqli_fetch_array($result,MYSQLI_ASSOC)){
	
	echo "Invalid Username or Password";
	
}
?>