<?php
$conn=mysqli_connect("localhost","root","","jobejee");
session_start(); 

$email1=($_POST['email']);
$password1=($_POST['password']);


$result=mysqli_query($conn,"SELECT * FROM regexpector WHERE email='$email1' and password='$password1'");

while(mysqli_fetch_array($result,MYSQLI_ASSOC)){
  
  header("location:jobview.php");
} 
if(!mysqli_fetch_array($result,MYSQLI_ASSOC)){
	
	echo "Invalid username or password!!!";
	
}
?>